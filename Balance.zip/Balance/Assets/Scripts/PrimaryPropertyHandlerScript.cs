using UnityEngine;
using System.Collections;

public class PrimaryPropertyHandlerScript : MonoBehaviour {
	
	private GameObject subsidary;
	
	private bool hasProperty,growObject,shrinkObject, rotateObject;

	private float t, oldY, newY, oldYRotation, newYRotation;
	
	private Vector3 growFactor, shrinkFactor, originalLocalScale, dummyPosition, dummyRotation;
	
	private int propertyNumber;
	
	private Color originalColor;
	
	private Material originalMaterial;
	
	private Shader oldShader;
	
	// Use this for initialization
	void Start () {
		
		growFactor = new Vector3(transform.localScale.x,transform.localScale.y*2.0f,transform.localScale.z);
		shrinkFactor = new Vector3(transform.localScale.x/2.0f,transform.localScale.y/2.0f,transform.localScale.z/2.0f);
		t = 0;
		oldY = transform.position.y;
		newY = transform.localScale.y/4.0f;
		oldYRotation = transform.eulerAngles.y;
		newYRotation = oldYRotation + 90;
		
		growObject = false;
		shrinkObject = false;
		rotateObject = false;
		
		originalColor = renderer.material.color;
		
		originalLocalScale = transform.localScale;
		
		oldShader = renderer.material.shader;
		
		propertyNumber = -1;
	}
	
	// Update is called once per frame
	void Update () { // a bunch of if statements to control the different material properties
		if(propertyNumber == 0){
			if(shrinkObject){
				if(t < 1){
					dummyPosition = transform.position;
					dummyPosition.y = Mathf.Lerp(oldY,newY,t);
					transform.position = dummyPosition;
					transform.localScale = Vector3.Lerp(transform.localScale, shrinkFactor,t);
					t += Time.deltaTime;
				}
				else{
					shrinkObject = false; 
					t = 0;
					dummyPosition = transform.position;
					dummyPosition.y = Mathf.Lerp(oldY,newY,1);
					transform.position = dummyPosition;
					transform.localScale = Vector3.Lerp(transform.localScale, shrinkFactor,1);
				}
			}
		}
		else if(propertyNumber == 2){
			if(rotateObject){
				if(t < 1){
					dummyRotation = transform.eulerAngles;
					dummyRotation.y = Mathf.Lerp(oldYRotation,newYRotation,t);
					transform.eulerAngles = dummyRotation;
					t += Time.deltaTime;
				}
				else{
					rotateObject = false; 
					t = 0;
					dummyRotation = transform.eulerAngles;
					dummyRotation.y = Mathf.Lerp(oldYRotation,newYRotation,1);
					transform.eulerAngles = dummyRotation;
				}
			}
		}
		else if(propertyNumber == 4){
			if(growObject){
				if(t < 1){
					transform.localScale = Vector3.Lerp(transform.localScale, growFactor,t);
					t += Time.deltaTime;
				}
				else{
					growObject = false; 
					t = 0;
					transform.localScale = Vector3.Lerp(transform.localScale, growFactor,1);
				}
			}
		}
		else if(propertyNumber == 6){
			
		}
	}
	
	// this method sets the property of the primary and activates the characteristics
	public void activateProperty(int propertyIndex){
		hasProperty = true;
		Color color;
		switch(propertyIndex){
			case 0:	// shrinker
				shrinkObject = true;
				break;
			case 1: // sticker
				renderer.material.color = subsidary.renderer.material.color;
				break;
			case 2: // Rotator
				rotateObject = true;
				break;
			case 3:	// Accelerator
				renderer.material.color = subsidary.renderer.material.color;
				break;
			case 4:	// Grower
				growObject = true;
				break;
			case 5:	// Fluider
				renderer.material.shader = Shader.Find("Transparent/Diffuse");
				color = renderer.material.color;
				color.a = 175.0f/255;
				renderer.material.color = color;
				collider.isTrigger = true;
				break;
			case 6:	// Glower
				renderer.material.shader = Shader.Find("Self-Illumin/Diffuse");
				subsidary.GetComponentInChildren<Light>().intensity = 2;
				break;
			case 7:	// Solidifier
				renderer.material.shader = Shader.Find("Diffuse");
				collider.isTrigger = false;
				renderer.material.color = subsidary.renderer.material.color;
				break;
		}
		propertyNumber = propertyIndex;
	}
	
	// this method resets the object.
	private void resetPrimary(){
		if(subsidary.GetComponentInChildren<Light>() != null){
			subsidary.GetComponentInChildren<Light>().intensity = 0;
		}
		renderer.material.shader = oldShader;
		propertyNumber = -1;
		transform.localScale = originalLocalScale;
		renderer.material.color = originalColor;
		renderer.material.SetTexture("_MainTex",null);
		collider.isTrigger = false;
		growObject = false;
		t = 0;
		dummyPosition = transform.position;
		dummyPosition.y = oldY;
		transform.position = dummyPosition;
		dummyRotation = transform.eulerAngles;
		dummyRotation.y = oldYRotation;
		transform.eulerAngles = dummyRotation;
		rigidbody.isKinematic = true;
	}
	
	// this method controls the interactions of the player and the object when they enter the trigger area
	void OnTriggerEnter(Collider col){
		if(col.gameObject.tag == "Player"){
			if(propertyNumber == 5){
				col.gameObject.GetComponent<ThirdPersonController>().adjustCharacterSpeed(4.0f/5);
			}
		}
	}
	
	// this method controls the interactions of the player and the object when they exit the trigger area
	void OnTriggerExit(Collider col){
		if(col.gameObject.tag == "Player"){
			if(propertyNumber == 5){
				col.gameObject.GetComponent<ThirdPersonController>().resetCharacterSpeed();
			}
		}
	}
	
	public void setSubsidary(GameObject subsidaryObject){
		subsidary = subsidaryObject;
	}
	
	public void dismember(GameObject Alexandria){
		if(hasProperty){
			resetPrimary();
			subsidary.transform.LookAt(Alexandria.transform);
			subsidary.transform.position += subsidary.transform.forward * (((Vector3.Distance(transform.position,Alexandria.transform.position))/2.0f) + 1);
			subsidary.transform.localEulerAngles = new Vector3(0,0,0);
			subsidary.rigidbody.useGravity = true;
			subsidary.collider.enabled = true;
			subsidary.renderer.enabled = true;
			hasProperty = false;
		}
	}
	
	public bool getHasProperty(){
		return hasProperty;	
	}
	
	public int getPropertyNumber(){
		return propertyNumber;	
	}
}
