using UnityEngine;
using System.Collections;

public class QuestHandlerScript : MonoBehaviour {
	
	public GameObject NPCQuestGiver, leftGate, rightGate;
	
	private DialogScript dialogScript;
	
	private bool open, close;
	// Use this for initialization
	void Start () {
		dialogScript = NPCQuestGiver.GetComponent<DialogScript>();
		renderer.enabled = false;
		
		open = true;
		close = false;
	}
	
	// Update is called once per frame
	void Update () {
		if(dialogScript.getQuestAccepted()){
			if(open){
				leftGate.transform.Rotate(new Vector3(0,-90,0));
				rightGate.transform.Rotate(new Vector3(0,90,0));
				close = true;
				open = false;
			}
			renderer.enabled = true;
		}
		else{
			if(close){
				leftGate.transform.Rotate(new Vector3(0,90,0));
				rightGate.transform.Rotate(new Vector3(0,-90,0));
				close = false;
				open = true;
			}
			renderer.enabled = false;
		}
	}
	
	// This method ensures that when the player touches the quest item, it destroys itself and the quest is completeable. 
 	void OnTriggerEnter(Collider col){
		if(col.gameObject.tag == "Player" && dialogScript.getQuestAccepted()){
			dialogScript.turnInQuest();
			Destroy (gameObject);
		}
	}
}
