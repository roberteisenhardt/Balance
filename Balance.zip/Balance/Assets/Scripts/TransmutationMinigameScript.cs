using UnityEngine;
using System.Collections;

public class TransmutationMinigameScript : MonoBehaviour {
	
	private GameObject leftArrow, leftArrowBubble, upArrow, upArrowBubble,
					   downArrow,downArrowBubble,rightArrow,rightArrowBubble, activeArrow,activeArrowBubble;
	
	private RaycastHit hit;
	
	private Ray ray;
	
	private bool success,activate, arrowActive, popBubble;
	
	private int count,randomizer;
	
	private float t;
	
	private Vector3 scaleFactor, originalScale;
	
	private Color originalArrowColor, originalBubbleColor, tempArrowColor,tempBubbleColor;
	
	// Use this for initialization
	void Start () {
		
		leftArrow = GameObject.Find("CharacterCamera/LeftArrow");
		leftArrowBubble = GameObject.Find("CharacterCamera/LeftArrow/ArrowSphere");
		downArrow = GameObject.Find("CharacterCamera/DownArrow");
		downArrowBubble = GameObject.Find("CharacterCamera/DownArrow/ArrowSphere");
		upArrow = GameObject.Find("CharacterCamera/UpArrow");
		upArrowBubble = GameObject.Find("CharacterCamera/UpArrow/ArrowSphere");
		rightArrow = GameObject.Find("CharacterCamera/RightArrow");
		rightArrowBubble = GameObject.Find("CharacterCamera/RightArrow/ArrowSphere");
		
		turnOffArrows();
		
		t = 0;
		count = 0;
		scaleFactor = new Vector3(0.13f,0.13f,0.13f);
		originalScale = leftArrow.transform.localScale; //which arrow is arbitrary (all have same scale)
		randomizer = Random.Range(0,4);
		
		success = false;
		activate = false;
		arrowActive = false;
		popBubble = false;
		
	}
	
	// Update is called once per frame
	void Update () {
		if(activate){
			if(!arrowActive){
				spawnArrow();
				arrowActive = true;
			}
			
			if(Input.GetMouseButtonDown(0)){
				ray = Camera.main.ScreenPointToRay(Input.mousePosition);
				if(Physics.Raycast(ray,out hit)){
					if(hit.collider.tag == "Arrow" && hit.collider.gameObject.activeSelf){
						popBubble = true;
					}
				}
			}
			
			if(popBubble){
				if(t < 1){
					activeArrow.transform.localScale = Vector3.Lerp(originalScale,scaleFactor,t);
					activeArrow.renderer.material.color = Color.Lerp(originalArrowColor,tempArrowColor,t);
					activeArrowBubble.renderer.material.color = Color.Lerp(originalBubbleColor,tempBubbleColor,t);
					t+=Time.deltaTime*2;
				}
				else{
					t = 0;
					activeArrow.transform.localScale = originalScale;
					activeArrow.renderer.material.color = originalArrowColor;
					activeArrowBubble.renderer.material.color  = originalBubbleColor;
					count++;
					activeArrow.SetActive(false);
					activeArrowBubble.SetActive(false);
					popBubble = false;
					arrowActive = false;
				}
			}
			
			if(count == 5){
				turnOffArrows();
				count = 0;
				success= true;
				activate = false;
			}
		}
	}
	
	private void spawnArrow(){
		switch(randomizer){
			case 0:
				leftArrow.SetActive(true);
				leftArrowBubble.SetActive(true);
				activeArrow = leftArrow;
				activeArrowBubble = leftArrowBubble;
				originalArrowColor = leftArrow.renderer.material.color;
				originalBubbleColor = leftArrowBubble.renderer.material.color;
				break;
			case 1:
				downArrow.SetActive(true);
				downArrowBubble.SetActive(true);
				activeArrow = downArrow;
				activeArrowBubble = downArrowBubble;
				originalArrowColor = downArrow.renderer.material.color;
				originalBubbleColor = downArrowBubble.renderer.material.color;
				break;
			case 2:
				upArrow.SetActive(true);
				upArrowBubble.SetActive(true);
				activeArrow = upArrow;
				activeArrowBubble = upArrowBubble;
				originalArrowColor = upArrow.renderer.material.color;
				originalBubbleColor = upArrowBubble.renderer.material.color;
				break;
			case 3:
				rightArrow.SetActive(true);
				rightArrowBubble.SetActive(true);
				activeArrow = rightArrow;
				activeArrowBubble = rightArrowBubble;
				originalArrowColor = rightArrow.renderer.material.color;
				originalBubbleColor = rightArrowBubble.renderer.material.color;
				break;
		}
		tempArrowColor = originalArrowColor;
		tempArrowColor.a = 0;
		tempBubbleColor = originalBubbleColor;
		tempBubbleColor.a = 0;
		randomizer = Random.Range(0,4);
	}
	
	public void activateMinigame(){
		activate = true;
	}
	
	private void turnOffArrows(){
		leftArrow.SetActive(false);
		leftArrowBubble.SetActive(false);
		downArrow.SetActive(false);
		downArrowBubble.SetActive(false);
		upArrow.SetActive(false);
		upArrowBubble.SetActive(false);
		rightArrow.SetActive(false);
		rightArrowBubble.SetActive(false);
	}
	
	public bool getSuccess(){
		return success;	
	}
	
	public void setSuccess(bool truth){
		success = truth;	
	}
}
