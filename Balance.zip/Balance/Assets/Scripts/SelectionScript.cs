using UnityEngine;
using System.Collections;

public class SelectionScript : MonoBehaviour {
	public GameObject selectionCircle;
	
	public int subsidaryPropertyIndex = 0; 
	
	public string subsidaryName;
	
	public float transmutationY = 0;
	
	private Vector3 oldPosition;
	
	// Use this for initialization
	void Start () {
		oldPosition = transform.position;
		oldPosition.y += 1.0f;
		turnOffCircle();
	}
	
	// Update is called once per frame
	void Update () {
		if(transform.position.y < -100.0f){
			transform.position = oldPosition;
		}
	}
	
	// this method turns on the selection sphere
	public void turnOnCircle(){
		selectionCircle.SetActive(true);
	}
	
	// this method turns off the selection sphere
	public void turnOffCircle(){
		selectionCircle.SetActive(false);
	}
	
	// this method returns if the selection sphere is on
	public bool isCircleOn(){
		return selectionCircle.activeSelf;
	}
	
	// this method returns the material property index
	public int getPropertyIndex(){
		return subsidaryPropertyIndex;	
	}
	
	// this method returns the subsidary name of the material
	public string getSubsidaryName(){
		return subsidaryName;	
	}
	
	public float getTransmutationY(){
		return transmutationY;	
	}
}
