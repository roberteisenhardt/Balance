using UnityEngine;
using System.Collections;

public class DialogScript : MonoBehaviour {
	
	public string[] dialog;
	
	public string questDescription,questAcceptanceDialog, questDeclineDialog, questWaitingDialog, questCompletedDialog, playerOnAnotherQuestDialog;
	
	public int questNumber;
	
	public GameObject floatingIcon, floatingIconPosition;
	
	public Texture questionIcon, dotIcon, smileyIcon;
	
	private GameObject Alexandria, dialogCircleFrame, dialogBox, questBox, dialogText, questText;
	
	private bool dialogActive, questBoxActive, questDeclined,questAccepted, questCompleted, questTurnIn;
	
	private int index;
	
	private GUIText dialogTextScript;
	
	private AlexandriaScript alexandriaScript;
	
	private Vector3 oldEulerAngles;
	
	
	// Use this for initialization
	void Start () {
		
		Alexandria = GameObject.Find("Alexandria");
		dialogCircleFrame = GameObject.Find ("DialogBox/DialogCircleFrame");
		dialogBox = GameObject.Find("DialogBox");
		dialogText = GameObject.Find ("DialogText");
		dialogTextScript = dialogText.GetComponent<GUIText>();
		alexandriaScript = Alexandria.GetComponent<AlexandriaScript>();
		
		oldEulerAngles = transform.eulerAngles;
			
		questBoxActive = false;
		questAccepted = false;
		questDeclined = false;
		questCompleted = false;
		questTurnIn = false;
		
		formatMainDialog();
		turnOffDialog();
			
		if(floatingIcon != null){ // this allows for non-quest giving npcs to still work with solely dialog.
			questBox = GameObject.Find ("QuestBox");
			questText = GameObject.Find("QuestText");
			floatingIcon.renderer.material.SetTexture("_MainTex",questionIcon);
			questDescription = formatString(35,6,questDescription);
			questAcceptanceDialog = formatString(48,3,questAcceptanceDialog);
			questDeclineDialog = formatString(48,3,questDeclineDialog);
			questWaitingDialog = formatString(48,3,questWaitingDialog);
			questCompletedDialog = formatString(48,3,questCompletedDialog);
			playerOnAnotherQuestDialog = formatString(48,3,playerOnAnotherQuestDialog);
			questText.guiText.material.color = Color.black;
		}
		
		dialogText.guiText.material.color = Color.black;
	}
	
	// Update is called once per frame
	void Update () {
		if(floatingIcon != null){
			iconToPlayer();
			if(questBoxActive){
				if(Input.GetKeyDown("q")){ // is used to try to accept a quest
					if(alexandriaScript.getHasQuest()){ // cannot accept quest because player already has one
						questDeclined = true;
						turnOffQuestBox();
						turnOnDialog();
						dialogTextScript.text = playerOnAnotherQuestDialog;
					}
					else{ // accept quest
						acceptQuest();
						turnOffQuestBox();
						turnOnDialog();
						dialogTextScript.text = questAcceptanceDialog;
					}
				}
				else if(Input.GetKeyDown("e")){ // decline quest
					questDeclined = true;
					turnOnDialog();
					turnOffQuestBox();
					dialogTextScript.text = questDeclineDialog;
				}
			}
		}
		
		if(dialogActive){
			if(Input.GetMouseButtonDown(0)){ // goes through the dialog, and adjust the dialog depending on quest conditions
				if(questDeclined){
					questDeclined = false;
					turnOffDialog();
					alexandriaScript.turnOffDialog();
				}
				else if(questTurnIn){
					completeQuest();
					turnOffDialog();
					alexandriaScript.turnOffDialog();
				}
				else if(questCompleted || questAccepted){
					turnOffDialog();
					alexandriaScript.turnOffDialog();
				}
				else{
					index = index+2;
					if(index < dialog.Length){
						dialogTextScript.text = dialog[index];
					}
					else{
						turnOffDialog();
						if(floatingIcon != null){
							turnOnQuestBox();
						}
						else{
							alexandriaScript.turnOffDialog();	
						}
					}
				}
			}
		}
	}
	
	// this method turns on the dialog GUI and appriopriates the correct dialog. 
	public void turnOnDialog(){ 
		dialogActive = true;
		dialogTextScript.enabled = true;
		dialogBox.GetComponent<GUITexture>().enabled = true;
		dialogCircleFrame.GetComponent<GUITexture>().enabled = true;
		if(questAccepted){
			dialogTextScript.text = questWaitingDialog;
		}
		else if(questCompleted || questTurnIn){
			dialogTextScript.text = questCompletedDialog;
		}
		else{
			dialogTextScript.text = dialog[index];
		}
		rotateToObject(Alexandria.transform.position);
		Input.ResetInputAxes();
	}
	
	// this method formats the dialog to fit in the GUI box
	private void formatMainDialog(){
		string text;
		int textIndex;
		for(int i = 1; i < dialog.Length;i = i+2){
			text = dialog[i];
			textIndex = 48;
			if(textIndex < text.Length){
				if(text[textIndex] == ' '){
					text = text.Substring(0,textIndex) + "\n" + text.Substring(textIndex+1);
				}
				else{
					while(text[textIndex] != ' '){
						textIndex--;
					}
					text = text.Substring(0,textIndex) + "\n" + text.Substring(textIndex+1);
				}
			}
			textIndex = textIndex*2+2;
			if(textIndex < text.Length){
				if(text[textIndex] == ' '){		
					text = text.Substring(0,textIndex) + "\n" + text.Substring(textIndex+1);
				}
				else{
					while(text[textIndex] != ' '){
						textIndex--;
					}
					text = text.Substring(0,textIndex) + "\n" + text.Substring(textIndex+1);
				}
			}
			dialog[i] = text;
		}
	}
	
	// this method formats the string to fit in the quest box
	// indexDivider is the index in the string where it will check for spaces
	// numberOfLines is the number of lines the sentence breaks up into from indexDivider
	// phrase is the string that needs formattg
	private string formatString(int indexDivider, int numberOfLines, string phrase){
		string text;
		int textIndex;
		text = phrase;
		textIndex = indexDivider;
		for(int i = 0; i < numberOfLines; i++){
			if(textIndex < text.Length){
				if(text[textIndex] == ' '){
					text = text.Substring(0,textIndex) + "\n" + text.Substring(textIndex+1);
					textIndex = (indexDivider*(i+2))+2;
				}
				else{
					while(text[textIndex] != ' '){
						textIndex--;
					}
					text = text.Substring(0,textIndex) + "\n" + text.Substring(textIndex+1);
					textIndex = (indexDivider*(i+2))+2;
				}
			}
		}
		return text;
	}
	
	// this method rotates the NPC towards the player
	private void rotateToObject(Vector3 position){
		transform.LookAt(position);
		Vector3 eulerAngles = transform.rotation.eulerAngles;
		eulerAngles.x = 0;
		eulerAngles.z = 0;
		transform.rotation = Quaternion.Euler(eulerAngles);
	}
	
	// this method ensures that the icon is always staring at the camera, giving the impression of 3D.
	private void iconToPlayer(){
		floatingIconPosition.transform.LookAt(Camera.main.transform.position);
		Vector3 eulerAngles = floatingIconPosition.transform.rotation.eulerAngles;
		eulerAngles.y = eulerAngles.y + 270;
		eulerAngles.x = 0;
		eulerAngles.z = 0;
		floatingIconPosition.transform.rotation = Quaternion.Euler(eulerAngles);
	}
	
	// this method handles the conditions for accepting a quest
	public void acceptQuest(){
		questAccepted = true;
		floatingIcon.renderer.material.SetTexture("_MainTex", dotIcon);
		alexandriaScript.setQuestSummary(questDescription);
		alexandriaScript.setHasQuest(true);
		alexandriaScript.setQuestNPC(gameObject);
	}
	
	// this method handles the conditions for completing a quest
	public void completeQuest(){
		questTurnIn = false;
		questAccepted = false;
		questCompleted = true;
		floatingIcon.renderer.material.SetTexture("_MainTex",smileyIcon);
		alexandriaScript.setHasQuest(false);
		alexandriaScript.setQuestSummary("No available quest");
	}
	
	// this method handles the conditions for turning in a quest
	public void turnInQuest(){
		questAccepted = false;
		questTurnIn = true;
	}
	
	// this method turns off the dialog GUI
	private void turnOffDialog(){
		index = 1;
		transform.eulerAngles = oldEulerAngles;
		dialogActive = false;
		dialogTextScript.enabled = false;
		dialogBox.GetComponent<GUITexture>().enabled = false;
		dialogCircleFrame.GetComponent<GUITexture>().enabled = false;
	}
	
	// this method activates the quest box and text
	private void turnOnQuestBox(){
		questBoxActive = true;
		questBox.guiTexture.enabled = true;
		questText.guiText.enabled = true;
		questText.guiText.text = questDescription;
	}
	
	// this method deactivates the quest box and text
	private void turnOffQuestBox(){
		questBoxActive = false;
		questBox.guiTexture.enabled = false;
		questText.guiText.enabled = false;
	}
	
	// this method returns if the quest has been accepted
	public bool getQuestAccepted(){
		return questAccepted;	
	}
	
	// this method returns if the quest has been completed
	public bool getQuestCompleted(){
		return questCompleted;	
	}
	
	// this method returns if the quest has been turned in
	public bool getQuestTurnIn(){
		return questTurnIn;	
	}
	
	// this method cancels the quest being undertaken by the player and resets the quest and dialog settings. 
	public void cancelQuest(){
		questAccepted = false;
		floatingIcon.renderer.material.SetTexture("_MainTex",questionIcon);
	}
}
