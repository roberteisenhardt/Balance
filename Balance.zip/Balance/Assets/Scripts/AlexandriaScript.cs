using UnityEngine;
using System.Collections;

public class AlexandriaScript : MonoBehaviour {
	
	public float selectDistance,pickUpDistance, talkDistance, transmutationDistance, dismemberDistance;
	public GameObject hand, transmutationCircle;
	
	private RaycastHit hit , dummyPrimary;
	private Ray ray, itemRay;
	
	private GameObject[] primaries,subsidaries;
	
	private GameObject pickedUpSubsidary, selectedPrimary, selectedSubsidary, questButton, fadePlane,
					   questBoxWithoutChoices, questText, cancelButton, questNPC, itemDescriptionText;
	
	private float transmuteDistance, midPointX, midPointZ,aniTime, aniTime2, aniTime3, t, oldYPosition, newYPosition,
				  questIconFlashTime;
	
	private bool isBusy, handsAreFull, circlePrimaryOn, circleSubsidaryOn, beginTransmuteAnimation, flashingQuestIcon,
				 hasQuest, questIconFlashForward, itemTextUpdated, hasProperty, scriptActive, fade, accelerator;
	
	private Vector3 glyphCenter;
	
	private Quaternion oldPrimaryRotation;
	
	private string questSummary;
	
	private Color oldQuestIconColor, newQuestIconColor, dummyColor;
	
	private ThirdPersonCamera thirdPersonCameraScript;
	
	private ThirdPersonController thirdPersonControllerScript;
	
	private PrimaryPropertyHandlerScript PrimaryScript;
	
	private CharacterController AlexandriaCharacterController;
	
	// Use this for initialization
	void Start () {
		hit = new RaycastHit();
		
		primaries = GameObject.FindGameObjectsWithTag("Primary");
		subsidaries = GameObject.FindGameObjectsWithTag("Subsidary");
		questButton = GameObject.Find ("QuestButton");
		questBoxWithoutChoices = GameObject.Find("QuestBoxWithoutChoices");
		questText = GameObject.Find ("QuestText");
		cancelButton = GameObject.Find ("CancelButton");
		itemDescriptionText = GameObject.Find ("ItemNameText");
		fadePlane = GameObject.Find ("CharacterCamera/FadePlane");
		
		AlexandriaCharacterController = GetComponent<CharacterController>();
		thirdPersonCameraScript = GetComponent<ThirdPersonCamera>();
		thirdPersonControllerScript = GetComponent<ThirdPersonController>();
		
		transmuteDistance = 7.0f;
		questIconFlashTime = 0;
		oldYPosition = transform.position.y;
		newYPosition = transform.position.y;
		
		scriptActive = false;
		hasProperty = false;
		accelerator = false;
		beginTransmuteAnimation = false;
		transmutationCircle.SetActive(false);
		handsAreFull = false;
		circlePrimaryOn = false;
		circleSubsidaryOn = false;
		isBusy = false;
		hasQuest = false;
		flashingQuestIcon = false;
		cancelButton.guiTexture.enabled = false;
		questBoxWithoutChoices.guiTexture.enabled = false;
		itemTextUpdated = false;
		fade = false;
		thirdPersonControllerScript.isControllable = false;
		questIconFlashForward = true;
		
		questSummary = "No available quest";
		
		oldQuestIconColor = questButton.guiTexture.color;
		itemDescriptionText.guiText.material.color = Color.white;
		newQuestIconColor = new Color(200.0f/255,200.0f/255,200.0f/255);
		
		turnOffDialog();
		
	}
	
	// Update is called once per frame
	void Update () {
		if(fade){
			dummyColor = fadePlane.renderer.material.color;
		 	dummyColor.a -= (Time.deltaTime*300)/255.0f;
			fadePlane.renderer.material.color = dummyColor;
			if(fadePlane.renderer.material.color.a <= 0){
				dummyColor.a = 0;
				fadePlane.renderer.material.color = dummyColor;
				fade = false;
			}
		}
		
		if(scriptActive){
			
			newYPosition = transform.position.y;
			
			if(!isBusy){	
				
				displayItemNames();	// shows the names of the items when mouse hovers over them.
				if(Input.GetMouseButtonDown(1)){
					ray = Camera.main.ScreenPointToRay (Input.mousePosition);
					if(Physics.Raycast(ray,out hit)){
						if(hit.collider.tag == "Primary"){
							if(hit.distance < dismemberDistance){
								hit.collider.gameObject.GetComponent<PrimaryPropertyHandlerScript>().dismember(gameObject);
								hasProperty = false;
							}
						}
					}
				}
				else if(Input.GetKeyDown("q")){	// for selecting subsidary and primary
					AlexandriaCharacterController.enabled = false;
					ray = Camera.main.ScreenPointToRay (Input.mousePosition);
					if(Physics.Raycast(ray,out hit)){
						if(hit.distance < selectDistance){
							if(hit.collider.tag == "Subsidary"){
								if(hit.collider.GetComponent<SelectionScript>().isCircleOn()){
									hit.collider.GetComponent<SelectionScript>().turnOffCircle();
									circleSubsidaryOn = false;
								}
								else{
									foreach(GameObject subsidary in subsidaries){
										subsidary.GetComponent<SelectionScript>().turnOffCircle();
									}
									hit.collider.GetComponent<SelectionScript>().turnOnCircle();
									selectedSubsidary = hit.collider.gameObject;
									circleSubsidaryOn = true;
								}
							}
							else if(hit.collider.tag == "Primary"){
								if(hit.collider.GetComponent<SelectionScript>().isCircleOn()){
									hit.collider.GetComponent<SelectionScript>().turnOffCircle();
									circlePrimaryOn = false;
								}
								else{
									foreach(GameObject primary in primaries){
										primary.GetComponent<SelectionScript>().turnOffCircle();
									}
									hit.collider.GetComponent<SelectionScript>().turnOnCircle();
									selectedPrimary = hit.collider.gameObject;
									circlePrimaryOn = true;
									hasProperty = selectedPrimary.GetComponent<PrimaryPropertyHandlerScript>().getHasProperty();
								}
							}
						}
					}
					AlexandriaCharacterController.enabled = true;
				}
				
				else if(Input.GetKeyDown("e") && transmutationCircle.activeSelf && isGrounded() && checkTransmutationDistance()){	// perform alchenetics
					if(handsAreFull){
						handsAreFull = false;
						pickedUpSubsidary.collider.enabled = true;
					}
					rotateToObject(transmutationCircle.transform.position);
					isBusy = true;
					thirdPersonControllerScript.isControllable = false;
					beginTransmuteAnimation = true;
					selectedPrimary.collider.enabled = false;
					selectedSubsidary.rigidbody.useGravity = false;
					selectedSubsidary.collider.enabled = false;
					selectedPrimary.collider.GetComponent<SelectionScript>().turnOffCircle();
					selectedPrimary.collider.GetComponent<PrimaryPropertyHandlerScript>().setSubsidary(selectedSubsidary);
					selectedSubsidary.collider.GetComponent<SelectionScript>().turnOffCircle();
					glyphCenter = new Vector3(selectedPrimary.transform.position.x,selectedPrimary.transform.position.y,selectedPrimary.transform.position.z);
					oldPrimaryRotation = selectedPrimary.transform.rotation;
					aniTime = Time.time + 1.0f;	// number of seconds for 1st animation of alchenetics
					aniTime2 = Time.time + 4.0f; // number of seconds for 2nd animation of alchenetics
					aniTime3 = Time.time + 2.0f; // number of seconds for 3rd animation of alchenetics
				}
				
				else if(Input.GetMouseButtonDown(0)){	// to turn off quest box, to talk to npcs, or to pick up subsidaries
					if(questButton.guiTexture.HitTest(Input.mousePosition)){
							isBusy = true;
							flashingQuestIcon = false;
							questBoxWithoutChoices.guiTexture.enabled = true;
							questText.guiText.enabled = true;
							questIconFlashForward = true;
							if(hasQuest){
								cancelButton.guiTexture.enabled = true;
							}
							questIconFlashTime = 0;
							questButton.guiTexture.color = oldQuestIconColor;
							questText.guiText.text = questSummary;
					}
					else{
						AlexandriaCharacterController.enabled = false;
						ray = Camera.main.ScreenPointToRay (Input.mousePosition);
						if(Physics.Raycast(ray,out hit)){
							if(hit.collider.tag == "NPC" && isGrounded()){ // talking to npcs
								if(hit.distance < talkDistance){
									isBusy = true;
									thirdPersonControllerScript.isControllable = false;
									thirdPersonCameraScript.angularMaxSpeed = 0;
									rotateToObject(hit.collider.gameObject.transform.position);
									hit.collider.gameObject.GetComponent<DialogScript>().turnOnDialog();
								}
							}
							else if(handsAreFull){
								handsAreFull = false;
								pickedUpSubsidary.collider.enabled = true;
							}
							else if(hit.collider.tag == "Primary"){
								dummyPrimary = hit;
								dummyPrimary.collider.enabled = false;
								ray = Camera.main.ScreenPointToRay (Input.mousePosition);
								if(Physics.Raycast(ray,out hit)){
									if(hit.collider.tag == "Subsidary" && !handsAreFull){
										if(hit.distance < pickUpDistance){
											handsAreFull = true;
											pickedUpSubsidary = hit.collider.gameObject;
											pickedUpSubsidary.collider.enabled = false;
										}
									}
								}
								dummyPrimary.collider.enabled = true;
							}
							else if(hit.collider.tag == "Subsidary" && !handsAreFull){ // picking up subsidaries
								if(hit.distance < pickUpDistance){
									handsAreFull = true;
									pickedUpSubsidary = hit.collider.gameObject;
									pickedUpSubsidary.collider.enabled = false;
								}
							}
						}
						AlexandriaCharacterController.enabled = true;
					}
				}
			}
			
			else if(questBoxWithoutChoices.guiTexture.enabled){ // turn of quest box or cancel quest
				if(Input.GetMouseButtonDown(0)){
					isBusy = false;
					questBoxWithoutChoices.guiTexture.enabled = false;
					questText.guiText.enabled = false;
					cancelButton.guiTexture.enabled = false;
				}
				else if(Input.GetKeyDown("e") && cancelButton.guiTexture.enabled){
					if(questNPC != null && !questNPC.GetComponent<DialogScript>().getQuestTurnIn()){
						questNPC.GetComponent<DialogScript>().cancelQuest();
						questSummary = "No available quest";
						questText.guiText.text = questSummary;
						cancelButton.guiTexture.enabled = false;
						hasQuest = false;
					}
				}
			}
			
			if(handsAreFull){ // always keep object with the hand
				pickedUpSubsidary.transform.position = hand.transform.position;
			}
			
			if(beginTransmuteAnimation){ // begins and maintains the animation for alchenetics
				initiateAlchenetics();
			}
			
			if(circlePrimaryOn && circleSubsidaryOn){ // makes the transmutation circle active when the objects are in proximity of each other and are both selected
				if(Vector3.Distance(selectedPrimary.transform.position,selectedSubsidary.transform.position) < transmuteDistance && !hasProperty && !handsAreFull){
					if(!beginTransmuteAnimation){
						midPointX = (selectedSubsidary.transform.position.x+selectedPrimary.transform.position.x)*0.5f;
						midPointZ = (selectedSubsidary.transform.position.z+selectedPrimary.transform.position.z)*0.5f;
						transmutationCircle.transform.position = new Vector3(midPointX,selectedPrimary.transform.position.y - selectedPrimary.GetComponent<SelectionScript>().getTransmutationY(),midPointZ);
					}
					deactivateEverything(transmutationCircle,true);
				}
				else{
					deactivateEverything(transmutationCircle,false);
				}
			}
			else{
				deactivateEverything(transmutationCircle,false);
			}
			
			if(flashingQuestIcon){ // flash the quest icon for aesthetics when a change is made to the player's quest box.
				flashIconAnimate();
			}
			
			oldYPosition = transform.position.y;
		}
	}
	
	// This method animates the quest log button to flash. This indicates to the player that the quest box has been modified.
	private void flashIconAnimate(){
		if(questIconFlashForward){
			if(questIconFlashTime < 1){
				questButton.guiTexture.color = Color.Lerp(oldQuestIconColor, newQuestIconColor,questIconFlashTime);
				questIconFlashTime += 0.02f;
			}
			else{
				questIconFlashTime = 1;
				questIconFlashForward = false;
			}
		}
		else{
			if(questIconFlashTime > 0){
				questButton.guiTexture.color = Color.Lerp(oldQuestIconColor, newQuestIconColor,questIconFlashTime);
				questIconFlashTime -= 0.02f;
			}
			else{
				questIconFlashTime = 0;
				questIconFlashForward = true;
			}	
		}
	}
	
	// This method controls the animation for alchenetics 
	private void initiateAlchenetics(){
		if(Time.time < aniTime){
			selectedSubsidary.transform.Translate(Vector3.up*Time.deltaTime*2);
		}
		else{
			if(Time.time < aniTime2){
				selectedSubsidary.transform.Rotate(Vector3.down*5.0f);
				if(Time.time > aniTime3){
					selectedSubsidary.transform.position = Vector3.Lerp(selectedSubsidary.transform.position,glyphCenter,t);
					t+= Time.deltaTime*(1/2.0f);
				}
			}
			else{
				t = 0;
				selectedPrimary.transform.rotation = oldPrimaryRotation;
				beginTransmuteAnimation = false;
				isBusy = false;
				circlePrimaryOn = false;
				selectedPrimary.collider.enabled = true;
				circleSubsidaryOn = false;
				selectedSubsidary.renderer.enabled = false;
				selectedPrimary.renderer.material.SetTexture("_MainTex",selectedSubsidary.renderer.material.GetTexture("_MainTex"));
				selectedPrimary.GetComponent<PrimaryPropertyHandlerScript>().activateProperty(selectedSubsidary.GetComponent<SelectionScript>().getPropertyIndex());
				thirdPersonControllerScript.isControllable = true;
			}
		}
	}
	
	//this method ensures that the player looks in the direction of the position desired. 
	private void rotateToObject(Vector3 position){
		transform.LookAt(position);
		Vector3 eulerAngles = transform.rotation.eulerAngles;
		eulerAngles.x = 0;
		eulerAngles.z = 0;
		transform.rotation = Quaternion.Euler(eulerAngles);
	}
	
	// This method checks to see if the player is in proximity of the transmutation circle to activate alchenetics
	private bool checkTransmutationDistance(){
		if(Vector3.Distance(transmutationCircle.transform.position,transform.position)< transmutationDistance){
			return true;	
		}
		else{
			return false;	
		}
	}
	
	// this method deactivates or activates all children of a given gameobject.
	private void deactivateEverything(GameObject g, bool b){
		g.SetActive(b);
		
		foreach(Transform child in g.transform){
			deactivateEverything(child.gameObject,b);
		}
	}
	
	// This method turns off the dialog GUI. 
	public void turnOffDialog(){
		isBusy = false;
		thirdPersonCameraScript.angularMaxSpeed = 175;
		thirdPersonControllerScript.isControllable = true;
	}
	
	//this method checks to see if the player is not jumping.
	private bool isGrounded(){
		if( Mathf.Abs(oldYPosition - newYPosition) < 0.0001){
			return true;	
		}
		else{
			return false;	
		}
	}
	
	// this method sets the player's quest box text.
	public void setQuestSummary (string text){
		questSummary = text;	
	}
	
	// this method sets if the player has a quest or not. 
	public void setHasQuest(bool boolean){
		hasQuest = boolean;
		flashingQuestIcon = true;
	}
	
	// this method allows us to set who the npc is that we need to deliver the completed quest to. 
	public void setQuestNPC(GameObject NPC){
		questNPC = NPC;
	}
	
	// this method returns if the user has a quest already.
	public bool getHasQuest(){
		return hasQuest;	
	}
	
	// this method displays the names of the items. 
	private void displayItemNames(){
		itemRay = Camera.main.ScreenPointToRay(Input.mousePosition);
		if(Physics.Raycast(itemRay, out hit)){
			if(hit.collider.tag == "Subsidary"){
				itemDescriptionText.guiText.enabled = true;
				if(!itemTextUpdated){
					itemDescriptionText.guiText.text = hit.collider.gameObject.GetComponent<SelectionScript>().getSubsidaryName();
				}
				itemTextUpdated = true;
			}
			else{
				itemDescriptionText.guiText.enabled = false;
				itemTextUpdated = false;
			}
		}
		else{
			
		}
	}
	
	public void activateScript(){
		scriptActive = true;
		thirdPersonControllerScript.isControllable = true;
		fade = true;
	}
	
	void OnControllerColliderHit(ControllerColliderHit col){
		if(accelerator && isGrounded()){
				thirdPersonControllerScript.resetCharacterSpeed();
				accelerator = false;
		}	
		
		if(col.gameObject.tag == "Primary"){
			PrimaryScript = col.gameObject.GetComponent<PrimaryPropertyHandlerScript>();
			if(PrimaryScript.getPropertyNumber() == 1){
				thirdPersonControllerScript.isSticky(true);
			}
			else if(!accelerator && PrimaryScript.getPropertyNumber() == 3){
				thirdPersonControllerScript.adjustCharacterSpeed(1.1f);
				accelerator = true;
			}
		}
	}
}
