﻿using UnityEngine;
using System.Collections;

public class StartScreenHandler : MonoBehaviour {
	
	public AudioClip pressEnterSound;
	
	private GameObject background, transmutationTitle, pressEnter, startScreenCamera, fadePlane, characterCamera,
					   alexandria;
	
	private bool scriptActive, pressEnterFade, fadePlaneActivate;
	
	private Color dummyColor;
	
	// Use this for initialization
	void Start () {
		background = GameObject.Find("StartScreen/Background");
		transmutationTitle = GameObject.Find ("StartScreen/Balance/TransmutationCircle");
		pressEnter = GameObject.Find ("StartScreen/Balance/PressEnter");
		startScreenCamera = GameObject.Find ("StartScreen/StartScreenCamera");
		characterCamera = GameObject.Find ("CharacterCamera");
		fadePlane = GameObject.Find ("StartScreen/FadePlane");
		alexandria = GameObject.Find ("Alexandria");
	
		scriptActive = true;
		pressEnterFade = true;
		fadePlaneActivate = false;
		
		dummyColor = fadePlane.renderer.material.color;
		dummyColor.a = 0;
		fadePlane.renderer.material.color = dummyColor;
	}
	
	// Update is called once per frame
	void Update () {
		if(scriptActive){
			transmutationTitle.transform.Rotate(0,Time.deltaTime*10,0);
			
			background.renderer.material.SetTextureOffset("_MainTex",new Vector2(0,Time.time*0.05f));
			
			if(pressEnterFade){
				dummyColor = pressEnter.renderer.material.color;
				dummyColor.a -= (Time.deltaTime*100)/255.0f;
				pressEnter.renderer.material.color = dummyColor;
				if(pressEnter.renderer.material.color.a <= (100/255.0f)){
					pressEnterFade = false;
				}
			}
			else{
				dummyColor = pressEnter.renderer.material.color;
				dummyColor.a += (Time.deltaTime*100)/255.0f;
				pressEnter.renderer.material.color = dummyColor;
				if(pressEnter.renderer.material.color.a >= 1){
					pressEnterFade = true;
					dummyColor.a = 1;
					pressEnter.renderer.material.color = dummyColor;
				}
			}
			
			if(Input.GetKeyDown("return") && !fadePlaneActivate){
				fadePlaneActivate = true;
				characterCamera.audio.PlayOneShot(pressEnterSound);
			}
			
			if(fadePlaneActivate){
				dummyColor = fadePlane.renderer.material.color;
				dummyColor.a += (Time.deltaTime*80)/255.0f;
				fadePlane.renderer.material.color = dummyColor;
				if(fadePlane.renderer.material.color.a >= 1){
					fadePlaneActivate = false;
					scriptActive = false;
					dummyColor.a = 1;
					fadePlane.renderer.material.color = dummyColor;
					turnOffRenderers();
					resetStartScreen();
					alexandria.GetComponent<AlexandriaScript>().activateScript();
				}
			}
		}
	}
	
	private void turnOffRenderers(){
		background.renderer.enabled = false;
		transmutationTitle.renderer.enabled = false;
		pressEnter.renderer.enabled = false;
		startScreenCamera.camera.enabled = false;
	}
	
	private void turnOnRenderers(){
		background.renderer.enabled = true;
		transmutationTitle.renderer.enabled = true;
		pressEnter.renderer.enabled = true;
		startScreenCamera.camera.enabled = true;
	}
	
	private void resetStartScreen(){
		transmutationTitle.transform.localEulerAngles = Vector3.zero;
		
		dummyColor.a = 1;
		pressEnter.renderer.material.color = dummyColor;
		pressEnterFade = true;
		
		background.renderer.material.SetTextureOffset("_MainTex",new Vector2(0,0));
	}
	
	public void turnStartScreenOn(){
			scriptActive = true;
			turnOnRenderers();
	}
}
